﻿using TurkPosWSTEST;

namespace WebMvc.Models.PazaryeriTPLimitKontrol
{
    public class PazaryeriTPLimitKontrolSonucViewModel
    {
        public Sonuc_Limit2? Sonuc { get; set; }
    }
}