﻿namespace WebMvc.Models.PazaryeriTPLimitKontrol
{
    public class PazaryeriTPLimitKontrolViewModel
    {
        public string ETS_GUID { get; set; } = "0c13d406-873b-403b-9c09-a5766840d98c";
        public string GUID_AltUyeIsyeri { get; set; } = "e09219fc-ab42-4715-b066-4bef69017b22";
        public string Tutar_Odenecek { get; set; } = "1.7500";
    }
}