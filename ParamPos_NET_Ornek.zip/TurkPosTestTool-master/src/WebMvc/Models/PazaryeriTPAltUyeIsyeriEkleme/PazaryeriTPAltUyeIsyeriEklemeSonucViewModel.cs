﻿using TurkPosWSTEST;

namespace WebMvc.Models.PazaryeriTPAltUyeIsyeriEkleme
{
    public class PazaryeriTPAltUyeIsyeriEklemeSonucViewModel
    {
        public Sonuc_Uyelik? Sonuc { get; set; }
    }
}