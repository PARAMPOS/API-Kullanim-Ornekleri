﻿using TurkPosWSTEST;

namespace WebMvc.Models.TPIslemDekontGonder
{
    public class TPIslemDekontGonderSonucViewModel
    {
        public ST_Sonuc? Sonuc { get; set; }
    }
}