﻿using TurkPosWSTEST;

namespace WebMvc.Models.TPIslemOdemeOnProvKapa
{
    public class TPIslemOdemeOnProvKapaSonucViewModel
    {
        public ST_TP_Islem_Odeme_OnProvKapa? Sonuc { get; set; }
    }
}