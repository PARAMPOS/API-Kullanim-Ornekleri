﻿using TurkPosWSTEST;
using WebMvc.DTOs.Pazaryeri_TP_AltUyeIsyeri_Silme;

namespace WebMvc.Models.PazaryeriTPAltUyeIsyeriSilme
{
    public class PazaryeriTPAltUyeIsyeriSilmeSonucViewModel
    {
        public Pazaryeri_TP_AltUyeIsyeri_SilmeResponseDTO? Sonuc { get; set; }
    }
}