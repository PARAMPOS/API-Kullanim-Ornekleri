﻿using TP_KS;

namespace WebMvc.Models.KSKartEkle
{
    public class KSKartEkleSonucViewModel
    {
        public ST_KS_Kart_Ekle? Sonuc { get; set; }
    }
}