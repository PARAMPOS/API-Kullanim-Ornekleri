﻿using TurkPosWSTEST;

namespace WebMvc.Models.PazaryeriTPSiparisOnay
{
    public class PazaryeriTPSiparisOnaySonucViewModel
    {
        public STC_Sonuc? Sonuc { get; set; }
    }
}