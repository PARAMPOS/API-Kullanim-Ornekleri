﻿using TurkPosWSTEST;

namespace WebMvc.Models.TPOzelOranSKGuncelle
{
    public class TPOzelOranSKGuncelleSonucViewModel
    {
        public ST_Sonuc? Sonuc { get; set; }
    }
}