﻿using TurkPosWSTEST;

namespace WebMvc.Models.TPOzelOranSKGuncelle
{
    public class TPOzelOranSKGuncelleViewModel
    {
        public ST_WS_Guvenlik G { get; set; } = new() { CLIENT_CODE = "10738", CLIENT_USERNAME = "test", CLIENT_PASSWORD = "test" };
        public string GUID { get; set; } = "0c13d406-873b-403b-9c09-a5766840d98c";
        public string Ozel_Oran_SK_ID { get; set; } = "6";
        public string MO_1 { get; set; } = "0.000";
        public string MO_2 { get; set; } = "0.000";
        public string MO_3 { get; set; } = "0.000";
        public string MO_4 { get; set; } = "0.000";
        public string MO_5 { get; set; } = "0.000";
        public string MO_6 { get; set; } = "0.000";
        public string MO_7 { get; set; } = "0.000";
        public string MO_8 { get; set; } = "0.000";
        public string MO_9 { get; set; } = "0.000";
        public string MO_10 { get; set; } = "0.000";
        public string MO_11 { get; set; } = "0.000";
        public string MO_12 { get; set; } = "0.000";
    }
}