﻿using TP_KS;

namespace WebMvc.Models.KSKartSil
{
    public class KSKartSilSonucViewModel
    {
        public ST_Sonuc? Sonuc { get; set; }
    }
}