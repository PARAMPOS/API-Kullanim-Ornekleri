﻿using TurkPosWSTEST;

namespace WebMvc.Models.PazaryeriTPIptalIade
{
    public class PazaryeriTPIptalIadeSonucViewModel
    {
        public STC_SonucII? Sonuc { get; set; }
    }
}