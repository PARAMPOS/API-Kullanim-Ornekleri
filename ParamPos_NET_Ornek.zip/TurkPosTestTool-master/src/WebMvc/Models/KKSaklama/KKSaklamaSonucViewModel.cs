﻿using TurkPosWSTEST;

namespace WebMvc.Models.KKSaklama
{
    public class KKSaklamaSonucViewModel
    {
        public ST_KK_Saklama? Sonuc { get; set; }
    }
}