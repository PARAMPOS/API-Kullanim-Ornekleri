﻿using TurkPosWSTEST;

namespace WebMvc.Models.TPIslemIptalOnProv
{
    public class TPIslemIptalOnProvSonucViewModel
    {
        public ST_Sonuc? Sonuc { get; set; }
    }
}