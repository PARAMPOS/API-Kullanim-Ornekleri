﻿using TurkPosWSTEST;

namespace WebMvc.Models.TPIslemSorgulama4
{
    public class TPIslemSorgulama4SonucViewModel
    {
        public ST_Genel_Sonuc2? Sonuc { get; set; }
    }
}