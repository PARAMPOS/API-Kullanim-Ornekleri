﻿using TurkPosWSTEST;

namespace WebMvc.Models.TPIslemIptalIadeKismi2
{
    public class TPIslemIptalIadeKismi2SonucViewModel
    {
        public ST_Sonuc_II? Sonuc { get; set; }
    }
}