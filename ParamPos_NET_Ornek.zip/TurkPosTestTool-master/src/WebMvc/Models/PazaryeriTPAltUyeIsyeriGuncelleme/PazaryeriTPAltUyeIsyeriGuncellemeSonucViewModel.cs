﻿using TurkPosWSTEST;

namespace WebMvc.Models.PazaryeriTPAltUyeIsyeriGuncelleme
{
    public class PazaryeriTPAltUyeIsyeriGuncellemeSonucViewModel
    {
        public Sonuc_Uyelik? Sonuc { get; set; }
    }
}