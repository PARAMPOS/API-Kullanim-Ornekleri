﻿namespace WebMvc.Models.IlIlceListe
{
    public class IlIlceListeViewModel
    {
        public string Islem_Tip { get; set; } = "Ilce";
        public string Il_Kodu { get; set; } = "06";
        public string Uygulama_Tip { get; set; } = "web";
    }
}