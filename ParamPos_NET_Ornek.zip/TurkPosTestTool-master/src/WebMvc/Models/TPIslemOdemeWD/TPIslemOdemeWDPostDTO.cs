﻿namespace WebMvc.Models.TPIslemOdemeWD
{
    public class TPIslemOdemeWDPostDTO
    {
        public string? TURKPOS_RETVAL_Islem_ID { get; set; }
        public string? TURKPOS_RETVAL_Sonuc { get; set; }
        public string? TURKPOS_RETVAL_Sonuc_Str { get; set; }
        public string? TURKPOS_RETVAL_GUID { get; set; }
        public string? TURKPOS_RETVAL_Islem_Tarih { get; set; }
        public string? TURKPOS_RETVAL_Dekont_ID { get; set; }
        public string? TURKPOS_RETVAL_Tahsilat_Tutari { get; set; }
        public string? TURKPOS_RETVAL_Odeme_Tutari { get; set; }
        public string? TURKPOS_RETVAL_Siparis_ID { get; set; }
        public string? TURKPOS_RETVAL_Ext_Data { get; set; }
        public string? TURKPOS_RETVAL_Banka_Sonuc_Kod { get; set; }
        public string? TURKPOS_RETVAL_PB { get; set; }
        public string? TURKPOS_RETVAL_KK_No { get; set; }
        public string? TURKPOS_RETVAL_Taksit { get; set; }
        public string? TURKPOS_RETVAL_Hash { get; set; }
        public string? TURKPOS_RETVAL_Islem_GUID { get; set; }
        public string? TURKPOS_RETVAL_SanalPOS_Islem_ID { get; set; }
    }
}