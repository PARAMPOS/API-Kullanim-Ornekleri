﻿using TurkPosWSTEST;

namespace WebMvc.Models.PazaryeriTPSiparisDetayEkle
{
    public class PazaryeriTPSiparisDetayEkleSonucViewModel
    {
        public SE_Sonuc? Sonuc { get; set; }
    }
}