﻿using TurkPosWSTEST;

namespace WebMvc.DTOs.Payment_Hopi
{
    public class Payment_HopiRequestDTO
    {
        public CL_Req_Payment_Hopi d { get; set; } = null!;
    }
}