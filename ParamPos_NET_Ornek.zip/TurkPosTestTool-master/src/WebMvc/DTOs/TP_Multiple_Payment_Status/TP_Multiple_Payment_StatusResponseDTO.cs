﻿namespace WebMvc.DTOs.TP_Multiple_Payment_Status
{
    public class TP_Multiple_Payment_StatusResponseDTO
    {
        public int? Result_Code { get; set; }
        public string? Result_Message { get; set; }
        public string? Batch_ID { get; set; }
    }
}