﻿namespace WebMvc.DTOs.TP_KK_Verify
{
    public class TP_KK_VerifyPostDTO
    {
        public string? KK_VERIFY_Sonuc { get; set; }
        public string? KK_VERIFY_Sonuc_Str { get; set; }
        public string? KK_VERIFY_Data1 { get; set; }
        public string? KK_VERIFY_Data2 { get; set; }
        public string? KK_VERIFY_Data3 { get; set; }
        public string? KK_VERIFY_Data4 { get; set; }
        public string? KK_VERIFY_Data5 { get; set; }
    }
}