﻿namespace WebMvc.DTOs.Pazaryeri_TP_Iptal_Iade
{
    public class Pazaryeri_TP_Iptal_IadeResponseDTO
    {
        public string? Durum { get; set; }
        public string? Durum_Str { get; set; }
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
    }
}