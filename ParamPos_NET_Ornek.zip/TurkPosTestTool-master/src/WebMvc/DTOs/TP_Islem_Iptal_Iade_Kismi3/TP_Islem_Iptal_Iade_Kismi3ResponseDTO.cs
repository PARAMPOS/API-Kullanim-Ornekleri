﻿namespace WebMvc.DTOs.TP_Islem_Iptal_Iade_Kismi3
{
    public class TP_Islem_Iptal_Iade_Kismi3ResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? Banka_Sonuc_Kod { get; set; }
        public double? Bank_AuthCode { get; set; }
        public string? Bank_Trans_ID { get; set; }
        public string? Bank_Extra { get; set; }
        public double? Bank_HostRefNum { get; set; }
    }
}