﻿namespace WebMvc.DTOs.TP_Islem_Dekont_Gonder
{
    public class TP_Islem_Dekont_GonderResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? Banka_Sonuc_Kod { get; set; }
    }
}