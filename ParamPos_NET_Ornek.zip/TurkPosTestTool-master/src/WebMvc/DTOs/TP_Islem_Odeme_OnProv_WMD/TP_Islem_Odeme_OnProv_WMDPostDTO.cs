﻿namespace WebMvc.DTOs.TP_Islem_Odeme_OnProv_WMD
{
    public class TP_Islem_Odeme_OnProv_WMDPostDTO
    {
        public string? md { get; set; }
        public string? mdStatus { get; set; }
        public string? orderId { get; set; }
        public string? transactionAmount { get; set; }
        public string? islemGUID { get; set; }
        public string? islemHash { get; set; }
        public string? bankResult { get; set; }
        public string? dc { get; set; }
        public string? dcUrl { get; set; }
    }
}