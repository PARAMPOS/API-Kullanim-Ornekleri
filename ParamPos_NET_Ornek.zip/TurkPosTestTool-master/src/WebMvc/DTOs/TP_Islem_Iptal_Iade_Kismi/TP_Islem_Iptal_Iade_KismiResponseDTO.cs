﻿namespace WebMvc.DTOs.TP_Islem_Iptal_Iade_Kismi
{
    public class TP_Islem_Iptal_Iade_KismiResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? Banka_Sonuc_Kod { get; set; }
    }
}