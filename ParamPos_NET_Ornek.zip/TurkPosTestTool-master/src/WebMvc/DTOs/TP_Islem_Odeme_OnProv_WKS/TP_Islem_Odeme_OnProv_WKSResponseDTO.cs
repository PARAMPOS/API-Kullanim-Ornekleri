﻿namespace WebMvc.DTOs.TP_Islem_Odeme_OnProv_WKS
{
    public class TP_Islem_Odeme_OnProv_WKSResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public long? Islem_ID { get; set; }
        public string? UCD_URL { get; set; }
        public string? Islem_GUID { get; set; }
        public int? Banka_Sonuc_Kod { get; set; }
        public string? Siparis_ID { get; set; }
    }
}