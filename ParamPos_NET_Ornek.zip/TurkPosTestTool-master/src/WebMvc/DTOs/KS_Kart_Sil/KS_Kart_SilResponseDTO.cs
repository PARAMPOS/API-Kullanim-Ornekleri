﻿namespace WebMvc.DTOs.KS_Kart_Sil
{
    public class KS_Kart_SilResponseDTO
    {
        public int? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
    }
}