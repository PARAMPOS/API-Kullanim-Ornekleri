﻿using TurkPosWSTEST;

namespace WebMvc.DTOs.Il_Liste
{
    public class Il_ListeRequestDTO
    {
        public ST_WS_Guvenlik G { get; set; } = null!;
    }
}