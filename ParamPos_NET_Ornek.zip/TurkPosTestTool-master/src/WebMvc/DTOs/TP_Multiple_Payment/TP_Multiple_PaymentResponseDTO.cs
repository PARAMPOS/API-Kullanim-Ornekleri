﻿namespace WebMvc.DTOs.TP_Multiple_Payment
{
    public class TP_Multiple_PaymentResponseDTO
    {
        public int? Result_Code { get; set; }
        public string? Result_Message { get; set; }
        public string? Batch_ID { get; set; }
    }
}