﻿namespace WebMvc.DTOs.TP_Islem_Izleme
{
    public class TP_Islem_IzlemeResponseDTO
    {
        public TP_Islem_IzlemeDT_BilgiDTO? DT_Bilgi { get; set; }
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
    }
}