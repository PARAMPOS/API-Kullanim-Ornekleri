﻿namespace WebMvc.DTOs.Pazaryeri_TP_AltUyeIsyeri_Ekleme
{
    public class Pazaryeri_TP_AltUyeIsyeri_EklemeResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? GUID_AltUyeIsyeri { get; set; }
    }
}