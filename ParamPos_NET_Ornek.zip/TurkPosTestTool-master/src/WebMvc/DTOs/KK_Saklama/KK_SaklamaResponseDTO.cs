﻿namespace WebMvc.DTOs.KK_Saklama
{
    public class KK_SaklamaResponseDTO
    {
        public string? GUID { get; set; }
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
    }
}