﻿namespace WebMvc.DTOs.TP_WMD_UCD
{
    public class TP_WMD_UCDPostDTO
    {
        public string? md { get; set; }
        public string? mdStatus { get; set; }
        public string? orderId { get; set; }
        public string? transactionAmount { get; set; }
        public string? islemGUID { get; set; }
        public string? islemHash { get; set; }
        public string? bankResult { get; set; }
        public string? dc { get; set; }
        public string? dcURL { get; set; }
    }
}