﻿using TurkPosWSTEST;

namespace WebMvc.DTOs.MP_OrderCancelRefund
{
    public class MP_Order_Cancel_RefundRequestDTO
    {
        public CL_Req_MP_OCR d { get; set; } = null!;
    }
}