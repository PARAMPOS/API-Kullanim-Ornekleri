﻿namespace WebMvc.DTOs.Pazaryeri_TP_AltUyeIsyeri_Silme
{
    public class Pazaryeri_TP_AltUyeIsyeri_SilmeResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? GUID_AltUyeIsyeri { get; set; }
    }
}