﻿namespace WebMvc.DTOs.Vadeli_Islem_Izleme
{
    public class Vadeli_Islem_IzlemeInfoDTO
    {
        public string? AUTHENTICATIONNUMBER { get; set; }
        public string? PAYMENT_DATE { get; set; }
        public string? BANKCOMMISIONAMOUNT { get; set; }
        public string? CARDHOLDERNAME { get; set; }
        public string? CURRENCYCODE { get; set; }
        public string? PROVISIONNUMBER { get; set; }
        public string? REFERENCECODE { get; set; }
        public string? VPOSERPCODE { get; set; }
        public string? PROCESS_TYPE { get; set; }
        public string? REFUND_AMOUNT { get; set; }
        public string? RECEIPT_ID { get; set; }
        public string? INSTALLMENTDATE { get; set; }
        public string? INSTALLMENTCOUNT { get; set; }
        public string? INSTALLMENTNUMBER { get; set; }
        public string? INSTALLMENT_AMOUNT { get; set; }
        public string? PROCESSAMOUNT { get; set; }
        public string? PROCESSNETAMOUNT { get; set; }
    }
}