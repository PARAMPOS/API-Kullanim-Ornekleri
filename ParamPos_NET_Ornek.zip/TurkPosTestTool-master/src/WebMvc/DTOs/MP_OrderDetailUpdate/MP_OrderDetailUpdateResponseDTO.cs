﻿namespace WebMvc.DTOs.MP_OrderDetailUpdate
{
    public class MP_OrderDetailUpdateResponseDTO
    {
        public int? ResultCode { get; set; }
        public string? ResultDescription { get; set; }
    }
}