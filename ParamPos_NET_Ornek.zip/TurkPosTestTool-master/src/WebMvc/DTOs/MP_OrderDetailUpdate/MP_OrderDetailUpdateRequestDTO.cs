﻿using TurkPosWSTEST;

namespace WebMvc.DTOs.MP_OrderDetailUpdate
{
    public class MP_OrderDetailUpdateRequestDTO
    {
        public CL_Req_MP_ODU d { get; set; } = null!;
    }
}