﻿using TurkPosWSTEST;

namespace WebMvc.DTOs.MP_OrderDetailAdd
{
    public class MP_OrderDetailAddRequestDTO
    {
        public CL_Req_MP_ODA d { get; set; } = null!;
    }
}