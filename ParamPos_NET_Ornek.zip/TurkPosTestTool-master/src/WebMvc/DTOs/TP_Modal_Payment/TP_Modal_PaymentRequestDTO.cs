﻿using TurkPosWSTEST;

namespace WebMvc.DTOs.TP_Modal_Payment
{
    public class TP_Modal_PaymentRequestDTO
    {
        public CL_Req_Odeme d { get; set; } = null!;
    }
}