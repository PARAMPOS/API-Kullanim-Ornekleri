﻿namespace WebMvc.DTOs.TP_Modal_Payment
{
    public class TP_Modal_PaymentResponseDTO
    {
        public int? ResultCode { get; set; }
        public string? ResultDescription { get; set; }
        public string? URL { get; set; }
    }
}