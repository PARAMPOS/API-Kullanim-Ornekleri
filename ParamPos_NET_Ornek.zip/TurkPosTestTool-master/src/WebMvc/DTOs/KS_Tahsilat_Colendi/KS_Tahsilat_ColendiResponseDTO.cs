﻿namespace WebMvc.DTOs.KS_Tahsilat_Colendi
{
    public class KS_Tahsilat_ColendiResponseDTO
    {
        public long? Islem_ID { get; set; }
        public string? UCD_URL { get; set; }
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
    }
}