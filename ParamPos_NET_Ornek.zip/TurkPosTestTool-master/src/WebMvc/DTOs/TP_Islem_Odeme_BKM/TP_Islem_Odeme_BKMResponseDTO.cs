﻿namespace WebMvc.DTOs.TP_Islem_Odeme_BKM
{
    public class TP_Islem_Odeme_BKMResponseDTO
    {
        public string? Redirect_URL { get; set; }
        public int? Response_Code { get; set; }
        public string? Response_Message { get; set; }
    }
}