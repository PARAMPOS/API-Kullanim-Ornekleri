﻿using TurkPosWSTEST;

namespace WebMvc.DTOs.MP_OrderDetailList
{
    public class MP_OrderDetailListRequestDTO
    {
        public CL_Req_MP_ODL d { get; set; } = null!;
    }
}