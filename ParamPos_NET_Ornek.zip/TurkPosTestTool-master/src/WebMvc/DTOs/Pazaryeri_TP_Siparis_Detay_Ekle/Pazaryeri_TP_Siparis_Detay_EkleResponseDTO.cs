﻿namespace WebMvc.DTOs.Pazaryeri_TP_Siparis_Detay_Ekle
{
    public class Pazaryeri_TP_Siparis_Detay_EkleResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? GUID_AltUyeIsyeri { get; set; }
        public string? Tutar_Urun { get; set; }
        public string? Tutar_Odenecek { get; set; }
        public string? PYSiparis_GUID { get; set; }
        public string? SanalPOS_Islem_ID { get; set; }
        public string? Toplam_Tahsilat_Tutari { get; set; }
        public string? Pazaryeri_Limit { get; set; }
        public string? Yeni_Odenecek_Tutar { get; set; }
    }
}