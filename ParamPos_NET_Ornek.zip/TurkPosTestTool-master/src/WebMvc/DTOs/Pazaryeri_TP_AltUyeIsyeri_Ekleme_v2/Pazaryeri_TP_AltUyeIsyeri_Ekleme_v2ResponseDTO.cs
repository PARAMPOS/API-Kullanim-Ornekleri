﻿namespace WebMvc.DTOs.Pazaryeri_TP_AltUyeIsyeri_Ekleme_v2
{
    public class Pazaryeri_TP_AltUyeIsyeri_Ekleme_v2ResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? GUID_AltUyeIsyeri { get; set; }
    }
}