﻿namespace WebMvc.DTOs.Pazaryeri_TP_AltUyeIsyeri_Guncelleme
{
    public class Pazaryeri_TP_AltUyeIsyeri_GuncellemeResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? GUID_AltUyeIsyeri { get; set; }
    }
}