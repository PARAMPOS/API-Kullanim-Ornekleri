﻿using TurkPosWSTEST;

namespace WebMvc.DTOs.MP_OrderDetailQuery
{
    public class MP_OrderDetailQuerytRequestDTO
    {
        public CL_Req_MP_ODQ d { get; set; } = null!;
    }
}