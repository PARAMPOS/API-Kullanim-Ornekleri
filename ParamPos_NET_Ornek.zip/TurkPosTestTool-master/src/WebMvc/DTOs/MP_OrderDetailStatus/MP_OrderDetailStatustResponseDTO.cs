﻿namespace WebMvc.DTOs.MP_OrderDetailStatus
{
    public class MP_OrderDetailStatustResponseDTO
    {
        public int? ResultCode { get; set; }
        public string? ResultDescription { get; set; }
    }
}