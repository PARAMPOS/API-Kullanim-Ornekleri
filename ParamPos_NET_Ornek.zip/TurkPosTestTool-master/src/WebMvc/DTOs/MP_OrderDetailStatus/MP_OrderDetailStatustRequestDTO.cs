﻿using TurkPosWSTEST;

namespace WebMvc.DTOs.MP_OrderDetailStatus
{
    public class MP_OrderDetailStatustRequestDTO
    {
        public CL_Req_MP_ODS d { get; set; } = null!;
    }
}