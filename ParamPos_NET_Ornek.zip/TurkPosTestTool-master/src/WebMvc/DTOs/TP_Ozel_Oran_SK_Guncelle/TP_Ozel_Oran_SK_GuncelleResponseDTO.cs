﻿namespace WebMvc.DTOs.TP_Ozel_Oran_SK_Guncelle
{
    public class TP_Ozel_Oran_SK_GuncelleResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? Banka_Sonuc_Kod { get; set; }
    }
}