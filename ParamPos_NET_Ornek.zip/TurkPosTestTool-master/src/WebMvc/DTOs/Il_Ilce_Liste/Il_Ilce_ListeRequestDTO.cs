﻿namespace WebMvc.DTOs.Il_Ilce_Liste
{
    public class Il_Ilce_ListeRequestDTO
    {
        public string Islem_Tip { get; set; } = string.Empty;
        public string Il_Kodu { get; set; } = string.Empty;
        public string Uygulama_Tip { get; set; } = string.Empty;
    }
}