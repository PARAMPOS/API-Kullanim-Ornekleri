﻿namespace WebMvc.DTOs.Il_Ilce_Liste
{
    public class Il_Ilce_ListeResponseDTO
    {
        public List<Il_Ilce_ListeDT_BilgiDTO>? DT_Bilgi { get; set; }
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
    }
}