﻿namespace WebMvc.DTOs.BIN_SanalPos
{
    public class BIN_SanalPosResponseDTO
    {
        public BIN_SanalPosDT_BilgiDTO? DT_Bilgi { get; set; }
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
    }
}