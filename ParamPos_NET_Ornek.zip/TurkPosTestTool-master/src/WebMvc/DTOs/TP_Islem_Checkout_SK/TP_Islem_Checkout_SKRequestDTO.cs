﻿namespace WebMvc.DTOs.TP_Islem_Checkout_SK
{
    public class TP_Islem_Checkout_SKRequestDTO
    {
        public string CLIENT_CODE { get; set; } = string.Empty;
        public string GUID { get; set; } = string.Empty;
        public string IPAdr { get; set; } = string.Empty;
        public string KKB_IN { get; set; } = string.Empty;
        public string Tutar { get; set; } = string.Empty;
    }
}