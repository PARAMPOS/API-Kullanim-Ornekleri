﻿namespace WebMvc.DTOs.TP_Islem_Checkout_SK
{
    public class TP_Islem_Checkout_SKResponseDTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? KomisyonluTutar { get; set; }
    }
}