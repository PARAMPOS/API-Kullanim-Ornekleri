﻿namespace WebMvc.DTOs.TP_Islem_Odeme_WKS
{
    public class TP_Islem_Odeme_WKSPostDTO
    {
        public string? TURKPOS_RETVAL_Sonuc { get; set; }
        public string? TURKPOS_RETVAL_Sonuc_Str { get; set; }
        public string? TURKPOS_RETVAL_GUID { get; set; }
        public string? TURKPOS_RETVAL_Islem_Tarih { get; set; }
        public string? TURKPOS_RETVAL_Dekont_ID { get; set; }
        public string? TURKPOS_RETVAL_Tahsilat_Tutari { get; set; }
        public string? TURKPOS_RETVAL_Odeme_Tutari { get; set; }
        public string? TURKPOS_RETVAL_Siparis_ID { get; set; }
        public string? TURKPOS_RETVAL_Islem_ID { get; set; }
        public string? TURKPOS_RETVAL_Ext_Data { get; set; }
        public string? TURKPOS_RETVAL_Banka_Sonuc_Kod { get; set; }
        public string? TURKPOS_RETVAL_Hash { get; set; }
    }
}