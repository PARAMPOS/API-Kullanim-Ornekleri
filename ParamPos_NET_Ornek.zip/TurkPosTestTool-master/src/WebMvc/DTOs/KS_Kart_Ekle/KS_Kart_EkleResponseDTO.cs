﻿namespace WebMvc.DTOs.KS_Kart_Ekle
{
    public class KS_Kart_EkleResponseDTO
    {
        public int? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? KS_GUID { get; set; }
    }
}