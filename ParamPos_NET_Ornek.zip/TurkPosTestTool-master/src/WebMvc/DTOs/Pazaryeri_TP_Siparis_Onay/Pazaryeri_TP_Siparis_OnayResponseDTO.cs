﻿namespace WebMvc.DTOs.Pazaryeri_TP_Siparis_Onay
{
    public class Pazaryeri_TP_Siparis_OnayResponseDTO
    {
        public string? POS_Islem_Id { get; set; }
        public string? GUID_AltUyeIsyeri { get; set; }
        public string? Tutar_Urun { get; set; }
        public string? Tutar_Odenecek { get; set; }
        public string? Durum { get; set; }
        public string? Durum_Str { get; set; }
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
    }
}