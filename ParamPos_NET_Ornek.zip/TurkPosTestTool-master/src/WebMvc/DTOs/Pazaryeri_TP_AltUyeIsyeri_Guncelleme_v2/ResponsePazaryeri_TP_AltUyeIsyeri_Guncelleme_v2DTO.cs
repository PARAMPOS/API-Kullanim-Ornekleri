﻿namespace WebMvc.DTOs.Pazaryeri_TP_AltUyeIsyeri_Guncelleme_v2
{
    public class ResponsePazaryeri_TP_AltUyeIsyeri_Guncelleme_v2DTO
    {
        public string? Sonuc { get; set; }
        public string? Sonuc_Str { get; set; }
        public string? GUID_AltUyeIsyeri { get; set; }
    }
}